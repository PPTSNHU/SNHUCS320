/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Task;

import java.util.Scanner;

public class TaskService {
	public Task root;
	Scanner userInput = new Scanner(System.in);

	public TaskService() {
		root = null;
	}

	public Task addHelper(Task newTask, String taskId) {           //add function helper
		if (root == null) {
			root = newTask;
		}

		if (Integer.parseInt(root.iD) < Integer.parseInt(newTask.iD)) {
			root.left = addHelper(root.left, newTask.iD);
		} else if (Integer.parseInt(root.iD) > Integer.parseInt(newTask.iD)) {
			root.right = addHelper(root.right, newTask.iD);
		}

		return null;
	}

	public void addTask() {                                        // add Task function
		Task newTask = new Task(null, null);
		System.out.println("Task Name:");
		newTask.name = userInput.toString();
		System.out.println("Task Description:");
		newTask.descrip = userInput.toString();

		if (newTask.name == null) {
			throw new IllegalArgumentException("No Name Entered");
		}
		if (newTask.descrip == null) {
			throw new IllegalArgumentException("No Description Entered");
		}
		addHelper(newTask, newTask.iD);
	}
	
	public Task Search(String iD) {                                   // BST Search Function
		return SearchPointer(root, iD);
	}

	public Task SearchPointer(Task task, String iD) {         // Search Helper Function
		if (task == null) {
			System.out.println("No such Task");
		}
		if (iD == task.iD) {
			return task;
		}
		if (Integer.parseInt(iD) < Integer.parseInt(task.iD)) {
			return SearchPointer(task.left, iD);
		} else {
			return SearchPointer(task.right, iD);
		}
	}


	public void delete(String iD) {                          // delete Task function
		root = deleteHelper(root, iD);                
	}

	private Task deleteHelper(Task deletePtr, String deleteId) {            // delete function helper
		if (deletePtr == null) {
			return null;
		}

		if (Integer.parseInt(deleteId) < Integer.parseInt(deletePtr.iD)) {
			deletePtr.left = deleteHelper(deletePtr.left, deleteId);
		} else if (Integer.parseInt(deleteId) > Integer.parseInt(deletePtr.iD)) {
			deletePtr.right = deleteHelper(deletePtr.right, deleteId);
		} else {
			if (deletePtr.left == null) {
				return deletePtr.right;
			} else if (deletePtr.right == null) {
				return deletePtr.left;
			}

			deletePtr = minValue(deletePtr.right);
			deletePtr.right = deleteHelper(deletePtr.right, deletePtr.iD);
		}
		return deletePtr;
	}

	private Task minValue(Task minID) {                                   // minimum recurse function
		while (minID.left != null) {
			minID = minID.left;
		}
		return minID;
	}

}
