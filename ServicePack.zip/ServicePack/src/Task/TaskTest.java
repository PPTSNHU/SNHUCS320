/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Task;

import org.junit.jupiter.api.Assertions.*;

import Contact.Contact;

import org.junit.jupiter.api.Test;

class TaskTest {
	@Test
	void testCreateValidTask() {                                                       // Test to validate Task creation
		Task task = new Task("Digging Holes", "Digging Holes is hard work.");
		Assertions.assertNotNull(task.iD);
		Assertions.assertEquals("Digging Holes", task.getName());
		Assertions.assertEquals("Digging Holes is hard work.", task.getDescrip());
	}  
    @Test
    void testValidUniqueIDCreation() {                                                   // Test validating unique ID creation
    	Task task = new Task();
    	Task task2 = new Task();
    	Assertions.assertNotNull(task.iD);
    	Assertions.assertNotNull(task2.iD);
    	Assertions.assertNotEquals(task.iD, task2.iD);
    }

	@Test
	void testCreateTaskWithInvalidName() {                                             // Test to validate Task Name data
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, "Digging Holes is hard work."));
		Assertions.assertThrows(IllegalArgumentException.class,
				() -> new Task("Digging Holes Digging Holes Digging Holes Digging Holes Digging Holes",
						"Digging Holes is hard work."));
	}

	@Test
	void testCreateTaskWithInvalidDescription() {                                     // Test to Validate Description Data
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("Digging Holes", null));
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("Digging Holes",
				"This is a very long task description that exceeds the maximum length of 50 characters and should throw an exception"));
	}

	@Test
	void testSetTaskName() {                                                            // Setter Test for Task Name
		Task task = new Task("Digging Holes", "Digging Holes is hard work.");
		task.setName("Washing Cars");
		Assertions.assertEquals("Washing Cars", task.getName());
	}

	@Test
	void testSetTaskDescription() {                                                     // Setter Test for Task Description
		Task task = new Task("Buy Groceries", "Digging Holes is hard work.");
		task.setDescrip("Washing cars is wet work.");
		Assertions.assertEquals("Washing cars is wet work", task.getDescrip());
	}
}
