/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/

package Task;

import org.junit.jupiter.api.Assertions.*;

import Contact.Contact;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	private TaskService taskService;

	@BeforeEach                                                                              // Test setup before each test following test case
	void setUp() {
		taskService = new TaskService();
	}

	@Test
	void testAddTask() {                                                                      // Test adding a new task
		Task newTask = new Task("Digging Holes", "Digging holes is hard work.");
		taskService.addHelper(newTask, newTask.iD);
		Assertions.assertNotNull(taskService.root);
		Assertions.assertEquals(newTask, taskService.root);
	}
	@Test
	void testUpdateTaskData() {
		Task newTask = new Task("Digging Holes", "Digging holes is hard work.");                // Test Data Augmentation test
		newTask.setName("Washing Cars");
		Assertions.assertEquals("Washing Cars", newTask.name);
	}

	@Test
	void testAddTaskNoName() {                                                                   // Test adding a task with a missing name
		Task newTask = new Task(null, "Digging holes is hard work.");
		Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.addHelper(newTask, newTask.iD));
	}

	@Test 
	void testAddTaskNoDescription() {                                                             // Test adding a task with a missing description
		Task newTask = new Task("Digging Holes", null);
		Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.addHelper(newTask, newTask.iD));
	}

	@Test
	void testDeleteTask() {                                                                          // Test deleting a task
		Task newTask = new Task("Digging Holes", "Digging holes is hard work.");
		taskService.addHelper(newTask, newTask.iD);
		taskService.delete(newTask.iD);
		Assertions.assertNull(taskService.root);
	}

	@Test
	void testDeleteNonExistentTask() {                                                             // Test deleting a non-existent task
		taskService.delete("1234567890");
		Assertions.assertNull(taskService.root);
	}
}
