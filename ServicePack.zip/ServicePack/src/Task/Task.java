/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Task;

import java.util.concurrent.atomic.AtomicInteger;

public class Task {                                                                        // Initialize required variables of Task Class
	private static final AtomicInteger uniqueIDGenerator = new AtomicInteger(9);           // unique id
	public  final String iD;
	public String name;
	public String descrip;
	public Task left;                                                                      // BST pointers
	public Task right;

	private String iDCreator() {
		int idNum = uniqueIDGenerator.getAndIncrement();                                   // unique ID number generator
		return String.format("%010d", idNum);
	}

	public Task(String name, String descrip) {                                            // Task constructor
		this.iD = iDCreator();
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");         // error throw
		}
		if (descrip == null || descrip.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");    // error throw
		}

		this.name = name;
		this.descrip = descrip;

	}

	public String getName() {                                            //  Task variable setters / getters
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
	public String getId() {
		return iD;
	}

}
