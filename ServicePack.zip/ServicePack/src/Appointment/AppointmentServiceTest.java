/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Appointment;

import org.junit.jupiter.api.Assertions.*;

import Contact.Contact;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

class AppointmentServiceTest {
	private Date today;                                                                          // initialize test variables
	private Date tomorrow;
	public AppointmentService tester;
	
	@BeforeEach                                                             
	void Setup() {                                                                            // Test setup before each test case
		tester = new AppointmentService();
	}

	@Test
    void testAddAppointment() {
        Appointment apptTester = new Appointment(today, "Removal of extra parts.");            // test add appointment
        tester.addAppointment(apptTester, apptTester.iD);
        Assertions.assertNull(apptTester);
        Assertions.assertNotNull(tester.root);
    }
	@Test
	void testUpdateAppointmentData() {
		Appointment apptTester = new Appointment(today, "Removal of extra parts.");           // Test Data Augmentation test
		apptTester.setDescrip("Not removing extra parts");
		Assertions.assertEquals("Not removing extra parts", apptTester.descrip);
	}

    @Test
    void testInvalidDate() {                                                                  // test for bad date variable
    	Appointment apptTester = new Appointment(today, "Removal of extra parts.");
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment, "appointment1"));
    }

    @Test
    void testInvalidDescription() {                                                          // test for bad description variable
    	Appointment apptTester = new Appointment(today, "Removal of extra parts.");
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment, "appointment1"));
    }

    @Test
    void testDeleteAppointment() {                                                          // test delete appointment
    	Appointment apptTester = new Appointment(today, "Removal of extra parts.");
    	Appointment apptTester2 = new Appointment(tomorrow, "Removal of extra pieces.");
        tester.addAppointment(apptTester, "Removal of extra parts.");
        tester.addAppointment(apptTester2, "Removal of extra pieces.");
        Appointment apptTester = tester.deleteAppointment(apptTester, apptTester.iD);
        Assertions.assertNull(apptTester);
        Assertions.assertNotNull(tester.root);
        Assertions.assertEquals(apptTester2.getDate(), tester.root.getDate());
    }

 \
}
