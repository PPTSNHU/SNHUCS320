/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Appointment;
import java.util.Date;

public class AppointmentService {
	
	public Appointment root;                                                 // initialize root variable
	

	public AppointmentService() {                                              //  service default constructor
		root = null;
	}
	
	public Appointment addAppointment (Appointment appointment, String newID) {       // add appointment function
		
		if (appointment.date == null || appointment.descrip == null) {
			throw new IllegalArgumentException("Invalid Appointment");
		}
		if (root == null) {
			root = appointment; 
		}
		if (root.date.before(appointment.date)) {
			root.left = addAppointment(root.left, appointment.iD);                 // recurse through tree to sort by date
		} else if (root.date.after(appointment.date)) {
			root.right = addAppointment(root.right, appointment.iD);
		}
		return null;

	}
	public Appointment Search(String iD) {                                           // BST Search Function
		return SearchPointer(root, iD);
	}

	public Appointment SearchPointer(Appointment appointment, String iD) {         // Search Helper Function
		if (appointment == null) {
			System.out.println("No such Appointment");
		}
		if (iD == appointment.iD) {
			return appointment;
		}
		if (Integer.parseInt(iD) < Integer.parseInt(appointment.iD)) {
			return SearchPointer(appointment.left, iD);
		}
		else {
			return SearchPointer(appointment.right, iD);
		}
	}

	public Appointment deleteAppointment(Appointment deleteEntry, String deleteID) {    // delete appointment function
		if (deleteID == root.iD) {
			root = null;
		}
		if(deleteEntry.date.before(root.date)) {
			return deleteAppointment(root.left, deleteID);
		}
		if(deleteEntry.date.after(root.date)) {
			return deleteAppointment(root.right, deleteID);
		}
		
	    else {
         if (root.left == null) {
             return root.right;
         } else if (root.right == null) {
             return root.left;
         }
	    }
		deleteEntry = minValue(deleteEntry.right);
		deleteEntry.right = deleteAppointment(deleteEntry.right, deleteEntry.iD);
		
		return null;
	
	    
	}
	private Appointment minValue(Appointment minID) {                                 // minimum recurse function
		while (minID.left != null) { }
		return minID;
	}

	

}