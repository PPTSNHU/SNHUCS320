/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Appointment;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Date;
public class Appointment {
	private static final AtomicInteger uniqueIDGenerator = new AtomicInteger(7);  // unique number generator
	public final String iD;
	public Date date;
	public String descrip;
	public Appointment left;                                      // BST Pointers
	public Appointment right;
	
	
	private String iDCreator() {                                  // unique ID number generator
		int idNum = uniqueIDGenerator.getAndIncrement();
		return String.format("%010d", idNum);
	}
	public Appointment(Date date, String descrip) {              // Appointment Constructor
		this.iD = iDCreator();
		if (date.before(new Date()) || date == null) {
			throw new IllegalArgumentException("Invalid Date");
		}
		if (descrip == null || descrip.length() > 50) {
			throw new IllegalArgumentException("Invaalid Description");
			}
		this.descrip = descrip;
		this.date = date;
		}
	public String getiD() {                                     // Appointment variable  setters / getters
		return iD;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDescrip() {
		return descrip;
	}
	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
	
}
