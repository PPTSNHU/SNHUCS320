/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import Contact.Contact;

import java.util.Date;

class AppointmentTest {
	public final Date today;
	public Appointment tester;

	 @Test
	    void testCreateValidAppointment() {                                                      // Test creating a valid Contact
	        Appointment tester = new Appointment(today, "Removal of extra parts.");
	        Assertions.assertNotNull(tester.iD);
	        Assertions.assertEquals(today, tester.getDate());
	        Assertions.assertEquals("Removal of extra parts.", tester.getDescrip());
	}
	 @Test
	    void testValidUniqueIDCreation() {                                                   // Test validating unique ID creation
	    	Appointment appointmentTest = new Appointment();
	    	Appointment appointmentTest2 = new Appointment();
	    	Assertions.assertNotNull(appointmentTest.iD);
	    	Assertions.assertNotNull(appointmentTest2.iD);
	    	Assertions.assertNotEquals(appointmentTest.iD, appointmentTest2.iD);
	    }
	 @Test
	    void testInvalidDate() {
	        tester = new Appointment(today, "Removal of extra parts.");                    // test valid date
	        String description = "Removal of extra parts.";
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(today, description));
	    }

	    @Test
	    void testNullDate() {                                                             // test null date
	        String description = "Removal of extra parts.";
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, description));
	    }

	    @Test
	    void testInvalidDescription() {                                                  // test description length
	        Date date = today;
	        String description = "Removal of extra parts.    Removal of extra parts.    Removal of extra parts.  Removal of extra parts.";
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(date, description));
	    }

	    @Test
	    void testNullDescription() {                                                     // test null description
	        Date date = today;
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(date, null));
	    }
	}


