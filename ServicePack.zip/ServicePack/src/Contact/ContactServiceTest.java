/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Contact;

import org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	ContactService contactService;
	
	@BeforeEach                                                             // Test setup before each test following test case
	void Setup() {
		contactService = new ContactService();
			
	}
	@Test
    void testAddContact() {                                                  // Test adding a new contact
        Contact newContact = new Contact("John", "Smith", "1234567890", "New Address");
        contactService.addHelper(newContact, newContact.iD);
        Assertions.assertNotNull(contactService.Search(newContact.iD));
    }
	@Test
	void testUpdateContactData() {
		Contact newContact = new Contact("John","Smith", "1234567890", "New Address");   // Test Data Augmentation test
		newContact.setName("Paul");
		Assertions.assertEquals("Paul", newContact.name);
	}
	@Test
    void testSearchContact() {                                                   // Test searching for a contact
        Contact newContact = new Contact("John", "Smith", "1234567890", "New Address");
        contactService.addHelper(newContact, newContact.iD);
        Contact foundContact = contactService.Search(newContact.iD);
        Assertions.assertEquals(newContact, foundContact);
    }

    @Test
    void testDeleteContact() {                                                       // Test deleting a contact
        Contact newContact = new Contact("John", "Smith", "1234567890", "New Address");
        contactService.addHelper(newContact, newContact.iD);
        contactService.delete(newContact.iD);
        Assertions.assertNull(contactService.Search(newContact.iD));
    }
	}


