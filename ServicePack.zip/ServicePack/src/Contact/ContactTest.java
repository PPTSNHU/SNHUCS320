/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Contact;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class ContactTest {

    @Test
    void testCreateValidContact() {                                                      // Test creating a valid Contact
        Contact contact = new Contact("John", "Smith", "1234567890", "New Address");
        Assertions.assertNotNull(contact.iD);
        Assertions.assertEquals("John", contact.getName());
        Assertions.assertEquals("Smith", contact.getLastName());
        Assertions.assertEquals("1234567890", contact.getpNum());
        Assertions.assertEquals("New Address", contact.getAddress());
    }
    @Test
    void testValidUniqueIDCreation() {                                                   // Test validating unique ID creation
    	Contact contact = new Contact();
    	Contact contact2 = new Contact();
    	Assertions.assertNotNull(contact.iD);
    	Assertions.assertNotNull(contact2.iD);
    	Assertions.assertNotEquals(contact.iD, contact2.iD);
    }
    

    @Test
    void testCreateContactWithInvalidName() {                                             // Test creating a Contact with an invalid name
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Smith", "1234567890", "New Address"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("ThisIsANameThatIsTooLongAndShouldThrowAnException", "Smith", "1234567890", "New Address"));
    }

    @Test
    void testCreateContactWithInvalidLastName() {                                      // Test creating a Contact with an invalid last name
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", null, "1234567890", "New Address"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "ThisIsALastNameThatIsTooLongAndShouldThrowAnException", "1234567890", "New Address"));
    }

    @Test
    void testCreateContactWithInvalidPhoneNumber() {                                   // Test creating a Contact with an invalid phone number
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Smith", null, "New Address"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Smith", "12345678901", "New Address"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Smith", "123456789a", "New Address"));
    }

    @Test
    void testCreateContactWithInvalidAddress() {                                      // Test creating a Contact with an invalid address
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Smith", "1234567890", null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("John", "Smith", "1234567890", "ThisIsAnAddressThatIsTooLongAndShouldThrowAnException"));
    }

    @Test
    void testSetContactName() {                                                      // Test setting the name of a Contact
        Contact contact = new Contact("John", "Smith", "1234567890", "New Address");
        contact.setName("Jane");
        Assertions.assertEquals("Jane", contact.getName());
    }

    @Test
    void testSetContactLastName() {                                                 // Test setting the last name of a Contact
        Contact contact = new Contact("John", "Smith", "1234567890", "New Address");
        contact.setLastName("Smith");
        Assertions.assertEquals("Smith", contact.getLastName());
    }

    @Test
    void testSetContactPhoneNumber() {                                             // Test setting the phone number of a Contact
        Contact contact = new Contact("John", "Smith", "1234567890", "New Address");
        contact.setpNum("0987654321");
        Assertions.assertEquals("0987654321", contact.getpNum());
    }

    @Test
    void testSetContactAddress() {                                                // Test setting the address of a Contact
        Contact contact = new Contact("John", "Smith", "1234567890", "New Address");
        contact.setAddress("456 Oak Rd");
        Assertions.assertEquals("456 Oak Rd", contact.getAddress());
    }
}