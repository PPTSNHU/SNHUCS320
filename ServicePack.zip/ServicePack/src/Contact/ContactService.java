/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/

package Contact;

import java.util.Scanner;

public class ContactService {                                      
	private Contact root;                            // root
	Scanner userInput = new Scanner(System.in);      // scanner for user input

	public ContactService() {                        // Contact service default constructor
		root = null;
	}

	public Contact Search(String iD) {               // Search Function
		return SearchPointer(root, iD);
	}

	public Contact SearchPointer(Contact contact, String iD) {         // Search Helper Function
		if (contact == null) {
			System.out.println("No such Contact");
		}
		if (iD == contact.iD) {
			return contact;
		}
		if (Integer.parseInt(iD) < Integer.parseInt(contact.iD)) {
			return SearchPointer(contact.left, iD);
		} else {
			return SearchPointer(contact.right, iD);
		}
	}

	public Contact addHelper(Contact newEntry, String newId) {          // add contact helper function
		if (root == null) {
			root = newEntry;
		}
  
		if (Integer.parseInt(root.iD) < Integer.parseInt(newEntry.iD)) {
			root.left = addHelper(root.left, newEntry.iD);
		} else if (Integer.parseInt(root.iD) > Integer.parseInt(newEntry.iD)) {
			root.right = addHelper(root.right, newEntry.iD);
		}

		return null;
	}

	public void addContact() {                                         // add contact function
		Contact newContact = new Contact(null, null, null, null);
		System.out.println("Contact Name:");
		newContact.name = userInput.toString();
		System.out.println("Contact Last name:");
		newContact.lastName = userInput.toString();
		System.out.println("Phone Number:");
		newContact.pNum = userInput.toString();
		System.out.println("Address:");                                              // user input data? No UI FIXME add UI at later time
		newContact.address = userInput.toString();
		if (newContact.name == null) {
			throw new IllegalArgumentException("No Name Entered");
			}
		if (newContact.lastName == null) {
			throw new IllegalArgumentException("No Last Name Entered");
			}
		if (newContact.pNum == null) {
			throw new IllegalArgumentException("No Phone number Entered");
			}
		if (newContact.address == null) {
			throw new IllegalArgumentException("No Address Entered");
			}
		
		addHelper(newContact, newContact.iD);
	}
	
	public void delete(String iD) {                                                    // delete Contact function
		root = deleteHelper(root, iD);
	}

	private Contact deleteHelper(Contact deletePtr, String deleteId) {                 // delete helper function
		if (deletePtr == null) {
			return null;
		}

		if (Integer.parseInt(deleteId) < Integer.parseInt(deletePtr.iD)) {
			deletePtr.left = deleteHelper(deletePtr.left, deleteId);
		} else if (Integer.parseInt(deleteId) > Integer.parseInt(deletePtr.iD)) {
			deletePtr.right = deleteHelper(deletePtr.right, deleteId);
		} else {
			if (deletePtr.left == null) {
				return deletePtr.right;
			} else if (deletePtr.right == null) {
				return deletePtr.left;
			}

			deletePtr = minValue(deletePtr.right);
			deletePtr.right = deleteHelper(deletePtr.right, deletePtr.iD);
		}
		return deletePtr;
	}

	private Contact minValue(Contact minID) {                            // minimum recurse function
		while (minID.left != null) {
			minID = minID.left;
		}
		return minID;
	}
	
	 

}
