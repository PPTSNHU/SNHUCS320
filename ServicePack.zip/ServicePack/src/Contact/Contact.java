/*
CS-320-R4835 Software Test Automation& QA 24EW4
Peter Thoman
Project 1 Submission
*/
package Contact;

import java.util.concurrent.atomic.AtomicInteger;

public class Contact {                                                            // Initialize required variables of Contact Class
	private static final AtomicInteger uniqueIDGenerator = new AtomicInteger(7);  // unique id 
	public final String iD;                    
	public String name;
	public String lastName;
	public String pNum;
	public String address;
	public Contact left;                                                          // BST pointers
	public Contact right;
	
    
	private String iDCreator() {                                  // unique ID number generator
		int idNum = uniqueIDGenerator.getAndIncrement();
		return String.format("%010d", idNum);
	}
	

	public Contact(String name, String lastName, String pNum, String address) {               	// Contact Constructor
		this.iD = iDCreator();
		int i;
		if (name == null || name.length() > 10) {
			throw new IllegalArgumentException("Invalid Name");           // error throw
		}
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");     // error throw
		}
		if (pNum == null || pNum.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");   // error throw
		}
		for(i = 0; i < pNum.length(); ++i) {                                                   // verify numeral and not letter
			char x = pNum.charAt(i);
			if (!Character.isDigit(x)) {
				throw new IllegalArgumentException("Invalid Phone Number");    // error throw
			}
		}
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");     // error throw
		}
		this.name = name;
		this.lastName = lastName;
		this.pNum = pNum;
		this.address = address;
		left = null;
		right = null;

	}
	                                                                                         // contact variable setters / getters
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setpNum(String pNum) {
		this.pNum = pNum;
	}
	public String getpNum() {
		return pNum;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
                                                                                       
	public String getId() {
		return iD;
	}



	
	



}
